#!/bin/bash

echo "🔧 Исправление прав доступа Git для Termux/Android"

# Путь к проекту
PROJECT_PATH="/storage/emulated/0/TgProject"

# 1. Добавить в safe.directory
echo "1. Добавляю $PROJECT_PATH в safe.directory..."
git config --global --add safe.directory "$PROJECT_PATH"

# 2. Проверить настройки
echo "2. Проверяю настройки safe.directory:"
git config --global --get-all safe.directory

# 3. Исправить права доступа (если возможно)
echo "3. Исправляю права доступа к файлам..."
chmod 755 "$PROJECT_PATH" 2>/dev/null || echo "Не удалось изменить права, продолжаем..."

# 4. Проверить пользователя
echo "4. Текущий пользователь: $(whoami)"
echo "   ID пользователя: $(id -u)"
echo "   ID группы: $(id -g)"

# 5. Альтернативный вариант: использовать --safe-directory при вызове git
echo "5. Альтернативный вариант:"
echo "   Можно использовать: git -c safe.directory='$PROJECT_PATH' [команда]"

# 6. Создать алиас для удобства
echo "6. Создаю алиас git='git -c safe.directory=\"$PROJECT_PATH\"'"
alias git="git -c safe.directory='$PROJECT_PATH'"

echo "✅ Готово! Попробуйте выполнить git status"